<?php
// Text
$_['text_title'] = 'Credit Card / Debit Card (NOCHEX) <br/> <img src="image/nochex-cards.png" width="250px" />';